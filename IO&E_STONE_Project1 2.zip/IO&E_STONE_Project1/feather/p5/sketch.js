//Written by William Luk
// posts data to an Adafuit.io feed
let url = 'https://io.adafruit.com/api/v2/kenziestone7/feeds/testdata/data';

var data = 0;

function setup() {

    myButton1 = createButton('IN CLASS');
    myButton1.mousePressed(inclass);
    myButton1.mouseReleased(off);

    myButton2 = createButton('NOT IN CLASS');
    myButton2.mousePressed(notinclass);
    myButton2.mouseReleased(off);

}


function draw() {

    myButton1.style('background-color', '#FF0000')
    myButton2.style('background-color', '#90ee90')
    myButton1.position(500, 300)
    myButton2.position(800, 300)

}

function inclass() {
    data = 1;
    console.log(data);
    sendData(data);
}

function notinclass() {
    data = 2;
    console.log(data);
    sendData(data);
}

function off() {
    data = 0;
    console.log(data);
    sendData(data);
}

function sendData(turnOn) {
    let postData = {
        "value": turnOn,
        "X-AIO-Key": "aio_goJj65CNLcJ85JNE4c8WDf1AC4C7"
    };
    httpPost(url, 'json', postData, function (result) {
        console.log(result);
    });
}
